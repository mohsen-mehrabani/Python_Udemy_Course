CREATE VIEW localhistory as SELECT strftime('%Y-%m-%d %H:%M:%f', history.time, 'localtime') as localtime, history.account, history.amount from history order by history.time;

